package com.smita.kidsdraw;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;



public class MainActivity extends AppCompatActivity {
    private Context mContext;
    private Resources mResources;
    private RelativeLayout mRelativeLayout;
    private Button mButton,mButton2,mButton3,mButton4,save,load,clear;
    private ImageView mImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mContext = getApplicationContext();


        mResources = getResources();


        mRelativeLayout = (RelativeLayout) findViewById(R.id.rl);
        mButton = (Button) findViewById(R.id.btn);
        mImageView = (ImageView) findViewById(R.id.iv);
        mButton2 = (Button) findViewById(R.id.btn2);
        mButton3 = (Button) findViewById(R.id.btn3);
        mButton4 = (Button) findViewById(R.id.btn4);
        save=(Button) findViewById(R.id.btn8);
        load=(Button) findViewById(R.id.btn10);
        clear=(Button) findViewById(R.id.btn9);




        // Set a click listener for Button widget
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Initialize a new Bitmap object
                init();


             }

        });

        mButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               init2();
            }
        });

        mButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Initialize a new Bitmap object Bitmap bitmap = Bitmap.createBitmap(
                init();
    }
});

        mButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                init2();

            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mImageView.setImageResource(0);
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


        }

    public void init() {
        Bitmap bitmap = Bitmap.createBitmap(
                500, // Width
                500, // Height
                Bitmap.Config.ARGB_4444// Config
        );


        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        canvas.save(Canvas.ALL_SAVE_FLAG);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);

        paint.setStrokeWidth(1);
        paint.setAntiAlias(true);
        canvas.save(Canvas.ALL_SAVE_FLAG);
        int offset=150;

        canvas.drawLine(
                offset,
                canvas.getHeight() / 8,
                canvas.getWidth()-offset ,
                canvas.getHeight() / 8,
                paint// Paint
        );
        canvas.restore();
        mImageView.setImageBitmap(bitmap);
    }
    public void init2() {
        Bitmap bitmap = Bitmap.createBitmap(
                500, // Width
                500, // Height
                Bitmap.Config.ARGB_4444// Config
        );


        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        canvas.save(Canvas.ALL_SAVE_FLAG);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);

        paint.setStrokeWidth(1);
        paint.setAntiAlias(true);
        canvas.save(Canvas.ALL_SAVE_FLAG);
        int offset=100;
        canvas.rotate(90,
                canvas.getHeight() / 4,
                canvas.getHeight() / 4
        );

        canvas.drawLine(
                offset,
                canvas.getHeight() / 4,
                canvas.getWidth()-offset ,
                canvas.getHeight() / 4,
                paint// Paint
        );
        canvas.restore();
        mImageView.setImageBitmap(bitmap);
    }
}